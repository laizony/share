// ==UserScript==
// @name       Resize Image On "Open image in new tab"
// @name:zh-cn 右键在新标签中打开图片时显示最优化图像质量
// @version    0.5.10
// @description  Support: Google(G+ blogspot YouTube)\Tumblr\Twitter\Steam(Only user content)\weibo.com (And more...
// @description:zh-cn 支持：谷歌(G+ blogspot YouTube)、Tumblr、推特、Steam、新浪微博、知乎、豆瓣、百度贴吧
// @run-at     document-start
// @match      http://*.googleusercontent.com/*
// @match      https://*.googleusercontent.com/*
// @match      http://*.media.tumblr.com/*
// @match      https://*.media.tumblr.com/*
// @match      http://*.bp.blogspot.com/*
// @match      https://*.bp.blogspot.com/*
// @match      http://*.sinaimg.cn/*
// @match      https://*.sinaimg.cn/*
// @match      http://*.qpic.cn/*
// @match      http://*.twimg.com/*
// @match      https://*.twimg.com/*
// @match      http://*.zhimg.com/*
// @match      https://*.zhimg.com/*
// @match      http://*.douban.com/view/*
// @match      https://*.douban.com/view/*
// @match      http://*.doubanio.com/view/*
// @match      https://*.doubanio.com/view/*
// @match      http://imgsrc.baidu.com/*
// @match      http://imgsrc.bdimg.com/*
// @match      http://*.hiphotos.baidu.com/*
// @match      http://*.hiphotos.bdimg.com/*
// @match      http://images.akamai.steamusercontent.com/*
// @match      http://*.artstation.com/*
// @match      https://*.artstation.com/*
// @match      http://i.ytimg.com/*
// @match      https://i.ytimg.com/*
// @match      http://*.ggpht.com/*
// @match      https://*.ggpht.com/*
// @exclude    http://webcache.googleusercontent.com/*
// @exclude    https://webcache.googleusercontent.com/*
// @namespace https://greasyfork.org/users/2646
// @copyright  2016+, CLE
// ==/UserScript==

var url = document.location.toString();
var m = null;

//google
if( (m = url.match(/^(https?:\/\/\w+\.googleusercontent\.com\/.+\/)([^\/]+)(\/[^\/]+(\.(jpg|jpeg|gif|png|bmp|webp))?)(?:\?.+)?$/i)) ) {
	if(m[2] != "s0") {
		document.location = m[1] + "s0" + m[3];
	}
}
else if( (m = url.match(/^(https?:\/\/\w+\.googleusercontent\.com\/.+=)(.+)(?:\?.+)?$/i)) ) {
	if(m[2] != "s0") {
		document.location = m[1] + "s0";
	}
}
else if( (m = url.match(/^(https?:\/\/\w+\.ggpht\.com\/.+\/)([^\/]+)(\/[^\/]+(\.(jpg|jpeg|gif|png|bmp|webp))?)(?:\?.+)?$/i)) ) {
	if(m[2] != "s0") {
		document.location = m[1] + "s0" + m[3];
	}
}

//blogspot
else if( (m = url.match(/^(https?:\/\/\w+\.bp\.blogspot\.com\/.+\/)([^\/]+)(\/[^\/]+(\.(jpg|jpeg|gif|png|bmp|webp))?)(?:\?.+)?$/i)) ) {
	if(m[2] != "s0") {
		document.location = m[1] + "s0" + m[3];
	}
}

//youtube
else if( (m = url.match(/^(https?:\/\/i\.ytimg.com\/vi\/[^\/]+\/)(\w+)(\.(jpg|jpeg|gif|png|bmp|webp))(\?.+)?$/i)) ) {
	if(m[2] != "maxresdefault") {
		var ajax = new XMLHttpRequest();
		ajax.onreadystatechange=function() {
			if(ajax.status==200) {
				document.location = m[1] + "maxresdefault" + m[3];
			}else if(ajax.status==404) {
				if(m[5] || m[2] === "mqdefault")
					document.location = m[1] + "hqdefault" + m[3]; //need test
			}
		};
		ajax.open("HEAD", m[1] + "maxresdefault" + m[3], true);
		ajax.send();
	}
}

//tumblr
else if( (m = url.match(/^(https?:\/\/\d+\.media\.tumblr\.com\/.*tumblr_\w+_)(\d+)(\.(jpg|jpeg|gif|png|bmp|webp))(?:\?.+)?$/i)) ) {
	if(m[2]<1280) {
		var ajax = new XMLHttpRequest();
		ajax.onreadystatechange=function() {
			if(ajax.status==200) {
				document.location = m[1] + "1280" + m[3];
			}
		};
		ajax.open("HEAD", m[1]+"1280"+m[3], true);
		ajax.send();
	}
}

//twitter
else if( (m = url.match(/^(https?:\/\/\w+\.twimg\.com\/media\/(?:[^\/:]+\.(?:jpg|jpeg|gif|png|bmp|webp)))(:\w+)?(?:\?.+)?$/i)) ) {
	if ( m[2]===null || m[2] != ":orig" )
		document.location = m[1] + ":orig";
}

//Steam (Only user content)
else if( (m = url.match(/^(http:\/\/images\.akamai\.steamusercontent\.com\/[^\?]+)\?.+$/i)) ){
	document.location = m[1];
}

//性浪微博
else if( (m = url.match(/^(https?:\/\/ww\d+\.sinaimg\.cn\/)([a-zA-Z]\w+)(\/.+)(?:\?.+)?$/i)) ) {
	if(m[2] != "large") {
		document.location = m[1] + "large" + m[3];
	}
}

//疼逊微博
//注意：腾讯服务器会经常性自动跳转到t100错误服务器，致使本条自动跳转规则失效
//如果您的浏览器经常性出现错误提示，请删除或屏蔽此条规则，等我找到更好的方法跳转之后再更新
//SB腾讯！
else if( (m = url.match(/^(http:\/\/[\w\d]+\.qpic\.cn\/.+\/)(\d+)(?:\?.+)?$/i)) ) {
	if(m[2]<2000) {
		top.location=m[1] + "2000";
	}
	/*if(m[2]!=0) {
		document.location = m[1] + "0";
	}*/
}
/* 测试代码，依然无效...
else if( (m = url.match(/^http:\/\/t(\d+)\.qpic\.cn\/(mblogpic\/\w+\/)(\d+)$/i)) ) {
	if(m[1]==100){
		document.location = "http://t1.qpic.cn/" + m[2] + "2000";
	}else if(m[3]<2000){
		document.location = "http://t"+m[1]+".qpic.cn/" + m[2] + "2000";
	}
}*/

//zhihu
else if( (m = url.match(/^(https?:\/\/.+\.zhimg\.com\/[\w\-]+_)(\w+)(\.(jpg|jpeg|gif|png|bmp|webp))(?:\?.+)?$/i)) ){
	if(m[2]!="r") {
		document.location = m[1] + "r" + m[3];
	}
}

//douban
else if( (m = url.match(/^(https?:\/\/\w+\.douban(?:io)?\.com\/view\/(?:photo|commodity_story)\/)(\w+)(\/public\/.+\.(jpg|jpeg|gif|png|bmp|webp))(?:\?.+)?$/i)) ){
	if(m[2] != "raw"){
		var ajax = new XMLHttpRequest();
		ajax.onreadystatechange=function() {
			if(ajax.status==200) {
				document.location = m[1] + "raw" + m[3];
			}else if(ajax.status==404) {
				if(m[2] != "photo"){
					document.location = m[1] + "photo" + m[3];
				}
			}
		};
		ajax.open("GET", m[1]+"raw"+m[3], true);
		ajax.send();
	}
}

//artstation
else if( (m = url.match(/^(https?:\/\/cdn\w+\.artstation\.com\/.+\/)(\w+)(\/[^\/]+)$/i)) ){
	if(m[2] != "original") {
		document.location = m[1] + "original" + m[3];
	}
}

//百度贴吧（然而对于画质提升什么的并没有什么卵用...）
else if( !(m = url.match(/^http:\/\/imgsrc\.baidu\.com\/forum\/pic\/item\/.+/i)) ){
	if( (m = url.match(/^http:\/\/(?:imgsrc|\w+\.hiphotos)\.(?:bdimg|baidu)\.com\/(?:forum|album)\/.+\/(\w+\.(?:jpg|jpeg|gif|png|bmp|webp))(?:\?.+)?$/i)) ){
		document.location = "http://imgsrc.baidu.com/forum/pic/item/" + m[1];
	}
}
