// ==UserScript==
// @name        gwdang
// @name:zh-CN   购物党比价工具
// @namespace   no
// @description 京东.淘宝.天猫.易迅.亚马逊中国.一号店.苏宁易购.当当网.国美在线.新蛋网中国.拍拍网自动比价。不会被删的版本（大概
// @description:zh-CN 京东.淘宝.天猫.易迅.亚马逊中国.一号店.苏宁易购.当当网.国美在线.新蛋网中国.拍拍网自动比价。不会被删的版本（大概吧
// @include     http://*.jd.com/*
// @include     https://*.jd.com/*
// @include     http://*.taobao.com/*
// @include     https://*.taobao.com/*
// @include     http://*.tmall.com/*
// @include     https://*.tmall.com/*
// @include     http://*.yixun.com/*
// @include     http://*.51buy.com/*
// @include     http://*.amazon.cn/*
// @include     http://*.yhd.com/*
// @include     http://*.suning.com/*
// @include     http://*.dangdang.com/*
// @include     http://*.gome.com.cn/*
// @include     http://*.newegg.cn/*
// @include     http://*.paipai.com/*
// @version     1.0
// @grant 		none
// ==/UserScript==
(function(){
var s = document.createElement('script');s.setAttribute('src','https://greasyfork.org/scripts/14464-gwd/code/gwd.js');document.body.appendChild(s);
})()